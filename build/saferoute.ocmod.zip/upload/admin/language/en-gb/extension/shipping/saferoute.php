<?php

$_['heading_title']    = 'SafeRoute Shipping';

$_['text_extensions']  = 'Extensions';
$_['text_success']     = 'Settings successfully saved';
$_['text_edit']        = 'Edit';

$_['entry_geo_zone']   = 'Geographical zone';
$_['entry_token']      = 'Token';
$_['entry_shop_id']    = 'Shop ID';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sorting order';

$_['error_permission'] = 'You are not allowed to change the settings of the module SafeRoute.';