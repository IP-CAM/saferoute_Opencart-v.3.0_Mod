<?php

$_['text_title'] = 'Доставка SafeRoute';